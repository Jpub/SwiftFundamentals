// 2장 연습문제(SLA_Lab2) 솔루션

import UIKit

let score:Int = 67
let rate:Int = 12.5
let gpa:float_t = 4
let name:String = "Bill Johnson"
let nameGPA:String = "Jane Smith \(gpa)"
let exactValue:double_t = 27.84793392

var operand1 = 47.98
var operand2 = 78.881

println("\(operand1) + \(operand2)= \(operand1+operand2)")
println("\(operand1) - \(operand2)= \(operand1-operand2)")
println("\(operand1) * \(operand2)= \(operand1*operand2)")
println("\(operand1) / \(operand2)= \(operand1/operand2)")

