// 1장 연습문제(SLA_Lab1) 솔루션 

import UIKit

println("Mark Lassoff")
println("LearnToProgram, Inc.")
println("27 Hartford Tpke, Suite 206")
println("Vernon, CT 06066")

println(27*82)
println(541.33 - 61.888)
println(999/540)
